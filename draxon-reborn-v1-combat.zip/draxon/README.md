# Draxon Reborn V1 (base)

Client-side Fabric mod for Minecraft Java 1.21.11 (Java 21): glassmorphism ClickGUI, settings system, theme, config, event bus.

## Build
1. Generate the Gradle wrapper and exact versions at https://fabricmc.net/develop (Minecraft 1.21.11, Yarn), copy
   `gradlew`, `gradlew.bat` and `gradle/` into this repo, and put the version numbers into `gradle.properties`.
2. `./gradlew build` -> `build/libs/draxon-reborn-*.jar`. `./gradlew runClient` to test.

## Controls
Right Shift opens/closes the ClickGUI, ESC closes it. Right click on a module row expands its settings.
Gear button next to the search bar opens the Interface (theme) panel.

## Layout
- `core` Draxon, DraxonClient, EventBus, Events, KeybindManager, ConfigManager
- `module` Module, ModuleManager, Category  (no modules shipped: add yours with `ModuleManager.register(...)`)
- `setting` Boolean/Number/Mode/Color/Keybind/String/Multi settings
- `gui` ClickGuiScreen, SettingRenderer, ThemeManager, FontManager, AnimationManager, Icons
- `util` RenderUtils

Config is stored in `config/draxon/` (`theme.json`, `modules.json`, optional `fonts.txt`).
Fonts: Instrument Sans (SIL OFL), see `assets/draxon/font/OFL-InstrumentSans.txt`.

## Combat / Sword (added)
Systems (`dev.draxon.combat`): `TargetManager`, `RotationManager`, `DelayManager`, `CombatState`, `Geo`, `Keys`.
Modules (`dev.draxon.module.combat`): Targets, TriggerBot, AimAssist, AutoClicker, W-Tap, S-Tap, SprintReset, Velocity, HitSelect, TargetStrafe, ShieldDisabler, AutoSprint.
Velocity needs the mixin `dev.draxon.mixin.ClientPlayNetworkHandlerMixin` (`draxon.mixins.json`); verify its target with `./gradlew genSources`.

Profiles (chat, never sent to the server): `.profile save|load|delete <name>`, `.profile list`, `.profile reset`, `.help`.
Files: `config/draxon/modules.json` (autosave) and `config/draxon/profiles/<name>.json`.
