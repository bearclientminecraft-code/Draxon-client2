# Draxon Reborn V1 (base)

Client-side Fabric mod for Minecraft Java 1.21.11 (Java 21): glassmorphism ClickGUI, settings system, theme, config, event bus.

## Build
1. Generate the Gradle wrapper and exact versions at https://fabricmc.net/develop (Minecraft 1.21.11, Yarn), copy
   `gradlew`, `gradlew.bat` and `gradle/` into this repo, and put the version numbers into `gradle.properties`.
2. `./gradlew build` -> `build/libs/draxon-reborn-*.jar`. `./gradlew runClient` to test.

## Controls
Right Shift opens/closes the ClickGUI, ESC closes it. Right click on a module row expands its settings.
Gear button next to the search bar opens the Interface (theme) panel.

## Layout
- `core` Draxon, DraxonClient, EventBus, Events, KeybindManager, ConfigManager
- `module` Module, ModuleManager, Category  (no modules shipped: add yours with `ModuleManager.register(...)`)
- `setting` Boolean/Number/Mode/Color/Keybind/String/Multi settings
- `gui` ClickGuiScreen, SettingRenderer, ThemeManager, FontManager, AnimationManager, Icons
- `util` RenderUtils

Config is stored in `config/draxon/` (`theme.json`, `modules.json`, optional `fonts.txt`).
Fonts: Instrument Sans (SIL OFL), see `assets/draxon/font/OFL-InstrumentSans.txt`.

## Combat / Sword (added)
Systems (`dev.draxon.combat`): `TargetManager`, `RotationManager`, `DelayManager`, `CombatState`, `Geo`, `Keys`.
Modules (`dev.draxon.module.combat`): Targets, TriggerBot, AimAssist, AutoClicker, W-Tap, S-Tap, SprintReset, Velocity, HitSelect, TargetStrafe, ShieldDisabler, AutoSprint.
Velocity needs the mixin `dev.draxon.mixin.ClientPlayNetworkHandlerMixin` (`draxon.mixins.json`); verify its target with `./gradlew genSources`.

Profiles (chat, never sent to the server): `.profile save|load|delete <name>`, `.profile list`, `.profile reset`, `.help`.
Files: `config/draxon/modules.json` (autosave) and `config/draxon/profiles/<name>.json`.

## Performance notes (GUI / HUD)
- Menu background blur is off by default (Interface -> "Background blur"); it is the most expensive part of the screen on weak GPUs.
- "Fast rendering" (Interface, on by default): switches, sliders, hover rows and other small shapes (radius <= 5) use hard-edged corners. Panel/pill corners stay anti-aliased with the same radius.
- The HUD is not drawn while the ClickGUI is open. ClickGUI: Up/Down (24px), PageUp/PageDown, Home/End scroll the module list under the cursor (or the last used one).

## Changes (latest)
- ShieldDisabler: Auto Hit (Hit Delay + Random, Miss Chance, optional Cooldown Check). Switches to an axe when the target blocks, hits, returns to the sword.
- W-Tap / S-Tap: tick-accurate, triggered by confirmed entity hits using the sprint state at the moment of the hit; Players Only; Double Tap Fallback when sprint is not held by a key. Defaults: W-Tap 1 tick, S-Tap 2 ticks.
- KeyBinds / Potion-list: fade + slide + zoom on appear/disappear, smooth height changes, rows fade in.
- Rounded shapes: small shapes use 2 anti-aliasing levels in Fast rendering (radius unchanged), everything else 4 levels.

## Player
AutoAccept (Only Friends, Teleport/Party/Duel/Custom toggles), AutoRespawn, AutoTool. Friends: `.friends add|del <name>`, `.friends list` (config/draxon/friends.json). Friends are never targeted by combat modules.

## Crystal / Anchor (added, untested)
AnchorMacro (Activate Key; Anchor/GlowStone/Totem slots; Delay + Random Delay), AutoInventoryTotem (on inventory open swaps a totem into Totem Slot), AutoHitCrystal (use key + crystal in hand -> attacks the crystal under the crosshair; Min/Max CPS, Hit Delay + Random Delay).
